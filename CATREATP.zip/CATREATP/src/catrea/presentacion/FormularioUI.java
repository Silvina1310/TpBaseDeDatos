package catrea.presentacion;

import catrea.bo.Carrera;
import catrea.bo.Preinscripcion;
import catrea.bo.Aspirante;
import catrea.bo.Operador;
import catrea.excepcion.BaseDeDatosException;
import catrea.excepcion.AspiranteExistenteException;
import catrea.excepcion.ServicioException;
import catrea.servicios.ManejadorPreinscripcion;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Mayra Estefania Ucedo
 */
public class FormularioUI extends javax.swing.JFrame {

    Operador usuario = null;
    List<Carrera> carreras = null; 
    ManejadorPreinscripcion servicioPostulacion = null;
    //para que vuelva al login
    LoginUI loginUI = null;
    
    /**
     * Creates new form FormularioUI
     */
    public FormularioUI(Operador usuario, LoginUI loginUI) {
        initComponents();
        servicioPostulacion = new ManejadorPreinscripcion();
        this.usuario = usuario;
        this.loginUI = loginUI;
        setearListener();
        obtenerInformacionCarreras();
        userLabel.setText(this.usuario.getNombre() + " " + this.usuario.getApellido());
        this.setLocationRelativeTo(null);
    }
    
    //metodo para obtener informacion sobre las carreras
    
    private void obtenerInformacionCarreras() {
        try {
            carreras = servicioPostulacion.obtenerCarreras();
            String[] modeloCarreras;
            //array de carreras
            modeloCarreras = new String[carreras.size() + 1 ];
            modeloCarreras[0] = "Elegir carreras";
            for(int i = 1; i < carreras.size(); i++) {
                modeloCarreras[i] = carreras.get(i).getNombre();
            }
            boxUno.setModel(new javax.swing.DefaultComboBoxModel<>(modeloCarreras));
        }catch (BaseDeDatosException e){
            mostrarMensajePantalla(e.getMessage(), "Error en la base de datos");
        }
    }               
    
    private void setearListener() {
        //para que no ingrese numeros en el campo nombre
        textoNombre.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                JTextField campo = (JTextField) e.getSource();
                boolean encontroNumero = false;
                for(char c:campo.getText().toCharArray()) {
                    if(Character.isDigit(c)) {
                        encontroNumero = true;
                        break;
                    }
                }
                if(encontroNumero) {
                    textoNombre.setText(null);
                    mostrarMensajePantalla("Ingrese solo letras", "Error");
                } 
            }
        });
        
        //para que no ingrese numeros en el campo apellido
        textoApellido.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                JTextField campo = (JTextField) e.getSource();
                boolean encontroNumero = false;
                for(char c:campo.getText().toCharArray()) {
                    if(Character.isDigit(c)) {
                        encontroNumero = true;
                        break;
                    }
                }
                if(encontroNumero) {
                    textoApellido.setText(null);
                    mostrarMensajePantalla("Ingrese solo letras", "Error");
                } 
            }
        });
        
        //para que no ingrese letras en el campo DNI
        textoDNI.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                JTextField campo = (JTextField) e.getSource();
                boolean encontroLetra = false;
                for(char c:campo.getText().toCharArray()) {
                    if(Character.isLetter(c)) {
                        encontroLetra = true;
                        break;
                    }
                }
                if(encontroLetra) {
                    textoDNI.setText(null);
                    mostrarMensajePantalla("Ingrese solo numeros", "Error");
                } 
            }
        });
        
        //para que no ingrese numeros en el campo localidad
        textoLocalidad.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                JTextField campo = (JTextField) e.getSource();
                boolean encontroNumero = false;
                for(char c:campo.getText().toCharArray()) {
                    if(Character.isDigit(c)) {
                        encontroNumero = true;
                        break;
                    }
                }
                if(encontroNumero) {
                    textoLocalidad.setText(null);
                    mostrarMensajePantalla("Ingrese solo letras", "Error");
                } 
            }
        });
        
        //para que no ingrese numeros en el campo provincia
        textoEstadoCivil.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                JTextField campo = (JTextField) e.getSource();
                boolean encontroNumero = false;
                for(char c:campo.getText().toCharArray()) {
                    if(Character.isDigit(c)) {
                        encontroNumero = true;
                        break;
                    }
                }
                if(encontroNumero) {
                    textoEstadoCivil.setText(null);
                    mostrarMensajePantalla("Ingrese solo letras", "Error");
                } 
            }
        });
        
        //para que no ingrese letras en el campo telefono
        textoTelefono.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                JTextField campo = (JTextField) e.getSource();
                boolean encontroLetra = false;
                for(char c:campo.getText().toCharArray()) {
                    if(Character.isLetter(c)) {
                        encontroLetra = true;
                        break;
                    }
                }
                if(encontroLetra) {
                    textoTelefono.setText(null);
                    mostrarMensajePantalla("Ingrese solo numeros", "Error");
                } 
            }
        }); 
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nombre = new javax.swing.JLabel();
        apellido = new javax.swing.JLabel();
        textoNombre = new javax.swing.JTextField();
        textoApellido = new javax.swing.JTextField();
        dni = new javax.swing.JLabel();
        textoDNI = new javax.swing.JTextField();
        localidad = new javax.swing.JLabel();
        provincia = new javax.swing.JLabel();
        mail = new javax.swing.JLabel();
        telefono = new javax.swing.JLabel();
        textoLocalidad = new javax.swing.JTextField();
        textoEstadoCivil = new javax.swing.JTextField();
        textoMail = new javax.swing.JTextField();
        textoTelefono = new javax.swing.JTextField();
        botonFormulario = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        boxUno = new javax.swing.JComboBox<>();
        userLabel = new javax.swing.JLabel();
        botonLogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        textoEstudio = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        nombre.setText("Nombre");

        apellido.setText("Apellido");

        textoNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoNombreActionPerformed(evt);
            }
        });

        textoApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoApellidoActionPerformed(evt);
            }
        });

        dni.setText("DNI");

        textoDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoDNIActionPerformed(evt);
            }
        });
        textoDNI.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                textoDNIKeyTyped(evt);
            }
        });

        localidad.setText("Localidad");

        provincia.setText("Estado Civil");

        mail.setText("Mail");

        telefono.setText("Teléfono");

        textoLocalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoLocalidadActionPerformed(evt);
            }
        });

        textoEstadoCivil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoEstadoCivilActionPerformed(evt);
            }
        });

        textoMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoMailActionPerformed(evt);
            }
        });

        textoTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoTelefonoActionPerformed(evt);
            }
        });
        textoTelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                textoTelefonoKeyTyped(evt);
            }
        });

        botonFormulario.setText("Guardar");
        botonFormulario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonFormularioActionPerformed(evt);
            }
        });

        jLabel2.setText("Carreras disponibles");

        boxUno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxUnoActionPerformed(evt);
            }
        });

        botonLogout.setText("Logout");
        botonLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLogoutActionPerformed(evt);
            }
        });

        jLabel1.setText("Nivel de estudio");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(apellido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(telefono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(provincia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(localidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(dni, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(221, 221, 221))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(userLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(166, 166, 166)
                        .addComponent(botonLogout)
                        .addGap(8, 8, 8))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonFormulario))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(boxUno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textoTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 52, Short.MAX_VALUE))
                    .addComponent(textoMail)
                    .addComponent(textoEstudio)
                    .addComponent(textoEstadoCivil)
                    .addComponent(textoLocalidad)
                    .addComponent(textoDNI)
                    .addComponent(textoApellido)
                    .addComponent(textoNombre))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonLogout)
                    .addComponent(userLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(nombre)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(textoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(apellido, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textoApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dni, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(textoDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(localidad, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textoLocalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(provincia, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textoEstadoCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textoEstudio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(mail)
                .addGap(18, 18, 18)
                .addComponent(textoMail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(telefono)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(textoTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(boxUno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonFormulario)
                .addGap(76, 76, 76))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textoApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoApellidoActionPerformed
        
    }//GEN-LAST:event_textoApellidoActionPerformed

    private void textoLocalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoLocalidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textoLocalidadActionPerformed

    private void textoTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoTelefonoActionPerformed
       
    }//GEN-LAST:event_textoTelefonoActionPerformed

    private void textoNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textoNombreActionPerformed

    private void textoDNIKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textoDNIKeyTyped
       
    }//GEN-LAST:event_textoDNIKeyTyped

    private void textoDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoDNIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textoDNIActionPerformed

    private void botonFormularioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonFormularioActionPerformed
        //las acciones que realiza el boton guardar
        if(evt.getSource() == botonFormulario) {
          if(textoNombre.getText().equals("")|| textoApellido.getText().equals("") || 
                textoDNI.getText().equals("") || textoLocalidad.getText().equals("")|| textoEstadoCivil.getText().equals("")
                || textoMail.getText().equals("") || textoTelefono.getText().equals("") || boxUno.getSelectedIndex()== 0 || 
                  textoEstadoCivil.getText().equals("") || textoEstudio.getText().equals("")) {
                mostrarMensajePantalla("Los campos estan vacios.",  "Error en la entrada de datos");
            } else {
              try {
                    ManejadorPreinscripcion servicioPreinscripcion = new ManejadorPreinscripcion();
                    Aspirante aspirante = new Aspirante(-1, textoNombre.getText(), textoApellido.getText(),textoDNI.getText(),
                    textoEstadoCivil.getText(),textoEstudio.getText(),textoLocalidad.getText(), textoMail.getText(), textoTelefono.getText());
                    Carrera carrera = carreras.get(boxUno.getSelectedIndex());
                    //creamos la postulacion
                    Date date = new Date();
                    Preinscripcion preinscripcion = new Preinscripcion(-1, date, aspirante, carrera, usuario);
                    //le damos de alta a postulacion
                    servicioPreinscripcion.crearPreinscripcion(preinscripcion);
                    mostrarMensajePantalla("Alta de preinscripcion exitosa!", "Operacion exitosa");
              } catch (AspiranteExistenteException ex) {
                 mostrarMensajePantalla(ex.getMessage(), "Error en la carga de preinscripcion"); 
              } catch (ServicioException ex) {
                  mostrarMensajePantalla(ex.getMessage(), "Error");
              }
          }
        }
    }//GEN-LAST:event_botonFormularioActionPerformed

    private void textoEstadoCivilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoEstadoCivilActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textoEstadoCivilActionPerformed

    private void textoTelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textoTelefonoKeyTyped
      
    }//GEN-LAST:event_textoTelefonoKeyTyped

    private void boxUnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxUnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_boxUnoActionPerformed

    private void textoMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoMailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textoMailActionPerformed

    private void botonLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLogoutActionPerformed
        //boton para desloguearse
        if(evt.getSource() == botonLogout) {
            this.usuario = null;
            carreras = null; 
            servicioPostulacion = null;
            this.setVisible(false);
            loginUI.setVisible(true);
        }    
    }//GEN-LAST:event_botonLogoutActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
    }
    
    //metodo que muestra un mensajes
    private void mostrarMensajePantalla(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje,
                   titulo,
                JOptionPane.ERROR_MESSAGE);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel apellido;
    private javax.swing.JButton botonFormulario;
    private javax.swing.JButton botonLogout;
    private javax.swing.JComboBox<String> boxUno;
    private javax.swing.JLabel dni;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel localidad;
    private javax.swing.JLabel mail;
    private javax.swing.JLabel nombre;
    private javax.swing.JLabel provincia;
    private javax.swing.JLabel telefono;
    private javax.swing.JTextField textoApellido;
    private javax.swing.JTextField textoDNI;
    private javax.swing.JTextField textoEstadoCivil;
    private javax.swing.JTextField textoEstudio;
    private javax.swing.JTextField textoLocalidad;
    private javax.swing.JTextField textoMail;
    private javax.swing.JTextField textoNombre;
    private javax.swing.JTextField textoTelefono;
    private javax.swing.JLabel userLabel;
    // End of variables declaration//GEN-END:variables
}
