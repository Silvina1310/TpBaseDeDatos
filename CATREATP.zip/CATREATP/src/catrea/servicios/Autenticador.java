package catrea.servicios;

import catrea.accesodatos.OperadoresDAO;
import catrea.bo.Operador;
import catrea.excepcion.BaseDeDatosException;
import catrea.excepcion.ContraseñaNoEncontradaException;
import catrea.excepcion.ServicioException;
import catrea.excepcion.OperadorNoEncontradoException;

/**
 *Se encarga de manejar el login del sistema
 * @author Mayra Estefania Ucedo
 */


public class Autenticador {
   
    public Operador autenticarOperador(String dni, String contrasenia) throws OperadorNoEncontradoException, 
            ContraseñaNoEncontradaException, ServicioException {
       try {
        OperadoresDAO dao = new OperadoresDAO();
        
        Operador operador= dao.recuperarOperador(dni);
        if(operador != null) {
            //compara dos objetos la que ingreso por teclado y la que tengo en la base de datos
            if(operador.getContraseña().equals(contrasenia)) {
                return operador;
            }   else {
                throw new ContraseñaNoEncontradaException("La contraseña es incorrecta");
            } 
        } else {
            throw new OperadorNoEncontradoException("El usuario" + dni + "no fue encontrado");
        } 
       } catch(BaseDeDatosException e) {
           throw new ServicioException(e.getMessage()) ;
       }
    }
}
