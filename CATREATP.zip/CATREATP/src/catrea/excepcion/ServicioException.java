package catrea.excepcion;

/**
 *
 * @author Mayra Estefania Ucedo
 */
public class ServicioException extends Exception{
    public ServicioException(String msg) {//constructor
        super(msg);
    }
}
