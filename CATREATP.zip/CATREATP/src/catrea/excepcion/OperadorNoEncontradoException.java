package catrea.excepcion;

/**
 *
 * @author Mayra Estefania Ucedo
 */
public class OperadorNoEncontradoException extends Exception {
    public OperadorNoEncontradoException(String msg) {//constructor
        super(msg);
    }
}
