package catrea.excepcion;

/**
 *
 * @author Mayra Estefania Ucedo
 */
public class BaseDeDatosException extends Exception {
    public BaseDeDatosException(String msg) {//constructor
        super(msg);
    }
}
    
