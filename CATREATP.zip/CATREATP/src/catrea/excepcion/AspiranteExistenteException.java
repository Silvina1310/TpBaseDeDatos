package catrea.excepcion;

/**
 *
 * @author Mayra Estefania Ucedo
 */
public class AspiranteExistenteException extends Exception {
    public AspiranteExistenteException(String msg) {//constructor
        super(msg);
    }
}
