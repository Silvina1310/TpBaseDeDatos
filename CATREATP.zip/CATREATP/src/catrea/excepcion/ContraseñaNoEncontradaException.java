package catrea.excepcion;

/**
 *
 * @author Mayra Estefania Ucedo
 */
public class ContraseñaNoEncontradaException extends Exception {
    public ContraseñaNoEncontradaException(String msg) {//constructor
        super(msg);
    }
}
    
